// import Home from "./Home";
import { addToCart, removeToCart } from "../services/actions/action";
import { connect } from "react-redux";
// import Home from "../components/Home";
import Home from "../components/Home";

const mapStateToProps = state=>({
    data:state.cartItmes
})
const mapDispatchToProps = dispatch =>({
    addToCartHandler:data=>dispatch(addToCart(data)),
    removeToCartHandler:data=>dispatch(removeToCart(data))
});
export default connect(mapStateToProps, mapDispatchToProps)(Home)