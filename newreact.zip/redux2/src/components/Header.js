import React from "react";
import { Button,Badge } from "react-bootstrap";
const Header = (props) =>{
    console.log("Header props", props);
    return (
        <>
            <div className="cart-button">
                <Button variant="primary">Cart Item <Badge bg="info"> {props.data.length} </Badge></Button>
            </div>
        </>
    )
}
export default Header