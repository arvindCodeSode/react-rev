import React from "react";
import { Button } from "react-bootstrap";


const Home = (props)=>{

    return(

        <>
            <div className="cart-wrapper">
                <div className="cart-image item">
                    <img alt="" src="" />
                </div>
                <div className="cart-price item">
                    <span>2000</span><br />
                    <span>I-Phone 15</span>
                </div>
                <div className="cart-button item">
                    <Button onClick={()=>{ props.addToCartHandler({price:2000,text:'I-Phone 15'}) }} variant="primary">Add to cart</Button>
                    <Button onClick={()=>{ props.removeToCartHandler() }} variant="danger">Add to cart</Button>
                </div>
            </div>
        </>
    )
}
export default Home