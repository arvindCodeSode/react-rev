import React, { useState } from "react"
import Footer from "../common/Footer";
import { useDispatch } from "react-redux";
import { addChatToDB } from "../../features/gpt/addChatSlice";

const AddChat = () =>{
    const [chat, setChat] = useState('');
    const dispatch =  useDispatch()


    async function addChat(){
        console.log('working', chat);
        dispatch( addChatToDB( {name:'Arvind Parkash',email:'arvind@gmail.com',prompt:chat} ))
        setChat('');
    }
    return (
        <div className="ar-chat-wrapper">
            <div className="ar-chat-input">
                <input type="text" value={chat} placeholder="Message YocGPT" onChange={(e)=>{setChat(e.target.value)}} />
                <button onClick={addChat} className="ar-button1"><i className="far fa-arrow-alt-circle-up" ></i></button>
                <button onClick={addChat} className="ar-button2"><i className="fa-solid fa-microphone" ></i></button>
            </div>
            <Footer></Footer>
        </div>
    )
}
export default AddChat;