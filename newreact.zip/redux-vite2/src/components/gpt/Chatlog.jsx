import React, { useState } from "react";
import { Button, Card, CardText, CardTitle, InputGroup, Form } from "react-bootstrap"
import Chat from "./Chat";

const Chatlog = () => {
    const [chat,setChat]=useState('');
    async function getChat(){
        if(chat.length>0){
            console.log('hello',chat);
        // let results = await fetch('', {
        //     method:'post',
        //     body:'',
        //     headers:{
        //         'Content-tpe':'application/json'
        //     }
        // });
        // console.log(results);
        setChat('');
        }
    }
    return (
        <>
            <div className="ar-chat-container">
                <Chat></Chat>
            </div>
        </>
    )
}
export default Chatlog;