import { createSlice,createAsyncThunk, nanoid } from "@reduxjs/toolkit";

const initialState = {
    chats:[],
    loading:false,
    error:null,
    singleChat:[]

}


export const addChatToDB = createAsyncThunk(
    'addChatToDB',
     async (data, {rejectWithValue})=>{
        try {
            
            let response = await  fetch(`http://localhost:5001/chats`,{
                method:'post',
                body:JSON.stringify(data),
                headers:{
                    'Content-Type':'application/json'
                }
            });
            response = await response.json();
            console.log(data);
            return response.data;
            // return data;

        } catch (error) {
            return rejectWithValue('Opps Found an error', error.message)
            
        }
     }
)
export const getChats = createAsyncThunk(
    'getChats',
    async ( args, { rejectWithValue } ) =>{
        try {
            let data = await fetch('http://localhost:5001/chats');
            let result = await data.json();
            return result.data;
        } catch (error) {
            return rejectWithValue('Opps Data not found', error.message)
        }        
    }
)


export const chatSlice = createSlice({
    name:'chatSlice',
    initialState,
    reducers:{
    
    },
    extraReducers:(builder)=>{
        builder
        .addCase(getChats.pending, (state)=>{
            state.loading=true;
        })
        .addCase(getChats.fulfilled , (state, action) =>{
            state.loading=false,
            state.chats= action.payload
            state.singleChat=[]

        }).addCase(getChats.rejected, (state, action)=>{
            state.loading=false;
            state.error = action.payload.error;
        }).addCase(addChatToDB.pending,(state)=>{
            state.loading=true;

        }).addCase(addChatToDB.fulfilled,(state,action)=>{
            state.loading=false;
            state.chats.push(action.payload);
        }).addCase(addChatToDB.rejected, (state, action)=>{
            state.loading=false;
            state.error=action.payload.error;
        });
    }
})

// export const {addChat,} = chatSlice.actions
export default chatSlice.reducer;