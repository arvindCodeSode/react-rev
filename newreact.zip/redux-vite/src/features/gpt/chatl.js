import { createSlice,createAsyncThunk, nanoid } from "@reduxjs/toolkit";

const initialState = {
    chats:[],
    loading:false,
    error:null,
    singleChat:[]

}

// Get all chat
export const getAllChats = createAsyncThunk(
    'getChats',
    async (args, {rejectWithValue})=>{
        try{
            const response = await fetch('https://api.github.com/users');
            const result = await response.json();
            return result;
        }catch(err){
            return rejectWithValue('Opps Found an error', err.response.data)
        }
    }
)

// export const getSingleChat = createAsyncThunk(
//     'singleChat',
//     async (id, { rejectWithValue }) =>{
//         try {
//             const response = await  fetch(`http://localhost:5000/getchat`,{
//                 method:'post',
//                 body:{q:'Hi'},
//                 headers:{
//                     'Conten-Type':'application/json'
//                 }
//             });
//             const result = await response.json();
            

//         } catch (error) {
//             return rejectWithValue('Opps Found an error', err.message)
            
//         }
//     }
// )
export const addMessage = createAsyncThunk(
    'addChat',
     async (data, {rejectWithValue})=>{
        try {
            console.log('helo')
            // let response = await  fetch(`http://localhost:5000/getchat`,{
            //     method:'post',
            //     body:JSON.stringify({q:'Hi'}),
            //     headers:{
            //         'Conten-Type':'application/json'
            //     }
            // });
            // console.log( await response.json());
            // return await response.json();

        } catch (error) {
            return rejectWithValue('Opps Found an error', error.message)
            
        }
     }
)
// export const updateChat = createAsyncThunk(
//     'updateChat',
//      async ({id,text,date}, {rejectWithValue})=>{
//         try {
//             const response = await fetch(
//                 '',
//                 {
//                     method:'PUT',
//                     headers:{
//                         'Content-type':'application/json'
//                     },
//                     body:JSON.stringify({text,date})
//                 }
//             )

//         } catch (error) {
//             return rejectWithValue('Opps Found an error', error.message)
            
//         }
//      }
// )

export const chatSlide = createSlice({
    name:'chatslice',
    initialState,
    reducers:{
        // addChat: (state,action) => {
        //     let date = new Date();
        //     const chat = {
        //         chatId:nanoid(),
        //         userId:1,
        //         chatDate:date.toLocaleDateString(),
        //         location:'Delhi',
        //         question:action.payload.question
        //     }
        //     state.chats.push(chat)
        // },
        // // updateChat: (state, action)=>{

        // // }
    },
    extraReducers:(builder)=>{
        builder.
        addCase( getAllChats.pending,(state)=>{
            state.loading=true
        })
        .addCase( getAllChats.fulfilled,(state,action)=>{
            state.loading=false,
            state.chats=action.payload,
            state.singleChat=[]
        })
        .addCase(getAllChats.rejected, (state,action) =>{
            state.loading=false,
            state.error=action.payload
        })
        .addCase(addMessage.pending, (state) =>{
            console.log(state);
            state.loading=true
        })
        .addCase(addMessage.fulfilled , (state, action) =>{
            state.loading=false,
            state.chats=action.payload
            state.singleChat=[]
        } )
        .addCase( addMessage.rejected, ( state, action ) =>{
            state.loading=false
        })
    }
})

export const {addChat} = chatSlide.actions
export default chatSlide.reducer;