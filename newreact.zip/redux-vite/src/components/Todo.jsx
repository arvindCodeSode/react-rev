import React from "react";
import {  useDispatch, useSelector } from "react-redux";
import { removeTodo } from "../features/todo/todoSlice";
import { Button } from "react-bootstrap";
function Todo(){
    const todos = useSelector(state=>state.todos);
    const dispatch = useDispatch();
    // dispatch(removeTodoHandler())
    function removeTodoHandler(id){
        dispatch(removeTodo(id));
    }

    return(
        <>
        <div>Todos</div>
            <ul>
            {
                todos.map((todo)=>(
                    <li key={todo.id}>
                        {todo.text}
                        <br />
                        <Button variant="danger" onClick={()=>{ removeTodoHandler(todo.id) }}>Delete</Button>
                    </li>
                ))
            }
            </ul>
        </>
    )
}
export default Todo