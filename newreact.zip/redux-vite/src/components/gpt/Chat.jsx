import React, { useEffect, useState } from "react";
import { Container } from "react-bootstrap";
const Chat = (props) => {
  const [chats, setChats] = useState([]);
  useEffect(() => {
    getChats();
  }, []);

  const getChats = async () => {
    try {
      let data = await fetch("http://localhost:5001/chats");
      let result = await data.json();
      setChats(result.data);
    } catch (error) {
      return rejectWithValue("Opps Data not found", error.message);
    }
  };
  console.log(props.chat)

  return (
    <>
      {chats.map((item, index) => (
        <Container key={index} className="ar-single-chat ">
          <div className="ar-chat ar-chatbox ">
            <div className="ar-img">
              <img src="user.png" alt="User Icon" />
            </div>
            <div className="ar-chat-chat">
              <div className="ar-username">You</div>
              <div className="ar-chat-content">
                <p>
                  {item.question} <i className="fas fa-edit"></i>
                </p>
              </div>
            </div>
          </div>

          <div className="ar-answer ar-chatbox ">
            <div className="ar-img">
              <img src="chatgpt.png" alt="User Icon" />
            </div>
            <div className="ar-chat-chat">
              <div className="ar-username">Chatgpt</div>
              <div className="ar-chat-content">{item.answer}</div>
            </div>
          </div>
        </Container>
      ))}
      <br />
    </>
  );
};
export default Chat;
