import { Col, Container, Row } from "react-bootstrap"
import Chatlog from "./Chatlog"
import Sidebar from "../common/Sidebar"
import Header from "../common/Header"
import AddChat from "./Addchat";
import Footer from "../common/Footer"

const ChatContainer = () => {
    return (
        <div>
            <div className="ar-left" id="style-2">
                <Sidebar></Sidebar>
            </div>
            <div className="ar-right"  >
                <Header></Header>
                <Chatlog></Chatlog>
               
                {/* <hr /> */}
                {/* <Footer></Footer> */}
            </div>
        </div>
    )

}
export default ChatContainer