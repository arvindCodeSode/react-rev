import React, { useState } from "react";
import {
  Button,
  Card,
  CardText,
  CardTitle,
  InputGroup,
  Form,
} from "react-bootstrap";
import Chat from "./Chat";
import AddChat from "./Addchat";
import Footer from "../common/Footer";

const Chatlog = () => {
    const [chat, setChat] = useState('');
    const [responseChat, setResponseChat] = useState([]);

    async function addChat(){
        try {
            
            let response = await  fetch(`http://localhost:5001/chats`,{
                method:'post',
                body:JSON.stringify({name:'Arvind Parkash',email:'arvind@gmail.com',prompt:chat} ),
                headers:{
                    'Content-Type':'application/json'
                }
            });
            response = await response.json();
            let resdata = response.data;
            console.log(resdata);
            // setResponseChat(response.data);
            responseChat.push(resdata);
            setResponseChat(responseChat);
            setChat('');
            

        } catch (error) {
            console.log(error);   
        }
    }

  return (
    <>
      <div className="ar-chat-container">
        <Chat></Chat>
        {responseChat.map((data,i)=>{
            return(
              <AddChat addchat={data}></AddChat>
            )
        })}
      </div>
      <div className="ar-chat-wrapper">
        <div className="ar-chat-input">
          <input
            type="text"
            value={chat}
            placeholder="Message YocGPT"
            onChange={(e) => {
              setChat(e.target.value);
            }}
          />
          <button onClick={addChat} className="ar-button1">
            <i className="far fa-arrow-alt-circle-up"></i>
          </button>
          <button onClick={addChat} className="ar-button2">
            <i className="fa-solid fa-microphone"></i>
          </button>
        </div>
        <Footer></Footer>
      </div>
    </>
  );
};
export default Chatlog;
