import React, { useState } from "react"
import { Container } from "react-bootstrap";

const AddChat = (props) =>{
    console.log(props);
    let item = props.addchat;

    if(props.addchat)
    {
        return (
                <>
                <Container  className="ar-single-chat ">
                  <div className="ar-chat ar-chatbox ">
                    <div className="ar-img">
                      <img src="user.png" alt="User Icon" />
                    </div>
                    <div className="ar-chat-chat">
                      <div className="ar-username">You</div>
                      <div className="ar-chat-content">
                        <p>
                          {item.question} <i className="fas fa-edit"></i>
                        </p>
                      </div>
                    </div>
                  </div>
        
                  <div className="ar-answer ar-chatbox ">
                    <div className="ar-img">
                      <img src="chatgpt.png" alt="User Icon" />
                    </div>
                    <div className="ar-chat-chat">
                      <div className="ar-username">Chatgpt</div>
                      <div className="ar-chat-content">{item.answer}</div>
                    </div>
                  </div>
                </Container>
              <br />
             </>
        )
    }
}
export default AddChat;