import React from "react";
import {useDispatch } from "react-redux";
import { getAllChats } from "../../features/gpt/addChatSlice";

const GetUser = () => {
    const dispatch = useDispatch('');
    return (
        <>
            <div>Hello World</div>
            <button type="button" onClick={()=>{ dispatch(getAllChats()) }}>Get User</button>
        </>
    )

}
export default GetUser;