import React from "react";

const Header = ()=>{

    return (
        <nav className="ar-right-header">
            <div >
                <b>YocGPT <span>1.0.0</span> <i className="fas fa-angle-down"></i></b>
            </div>
        </nav>
    )   
}
export default Header;