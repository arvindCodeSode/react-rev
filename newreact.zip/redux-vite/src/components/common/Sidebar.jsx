import { Link } from "react-router-dom";
import { Row, Col } from "react-bootstrap";

const Sidebar = () => {
    return (
        <div className="ar-sidebar">
            <div className="ar-topsidebar">
                <div className="ar-user">
                    <img src="gpt.png" alt="chatgpt icon" style={{ width: '30px' }} />
                    <span className="ar-task">New Task</span>
                </div>

                <div className="ar-newtask">
                    <span className="ar-addtask">New</span>
                </div>
            </div>
            <ul>
                <li>
                    <span>Previous 7 day</span>
                    <ul>
                        <li> <Link to='/chat1'>Chat 1</Link> </li>
                        <li> <Link to='/chat1'>Chat 2</Link> </li>
                        <li> <Link to='/chat1'>Chat 3</Link> </li>
                        <li> <Link to='/chat1'>Chat 4</Link> </li>
                    </ul>
                </li>
                <li>
                    <span>Previous 7 day</span>
                    <ul>
                        <li> <Link to='/chat1'>Chat 1</Link> </li>
                        <li> <Link to='/chat1'>Chat 2</Link> </li>
                        <li> <Link to='/chat1'>Chat 3</Link> </li>
                        <li> <Link to='/chat1'>Chat 4</Link> </li>
                    </ul>
                </li>
               
            </ul>
            <div className="ar-sidebar-footer">
                <div className="ar-user">
                        <div>
                        <i className="far fa-user"></i>
                        </div>
                        <span className="ar-task">Arvind Parkash</span>
                    </div>

            </div>
        </div>
    )
}
export default Sidebar;