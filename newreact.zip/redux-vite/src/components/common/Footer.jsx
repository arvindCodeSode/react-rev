import React from "react";

const Footer = ()=>{
    return (
        <div className="ar-right-footer">
            You Own ChatGPT <b>(YocGPT)</b> can make mistakes. Consider checking important information.
        </div>
    )   
}
export default Footer;