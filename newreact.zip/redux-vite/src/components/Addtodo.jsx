import { useState } from "react";
import { Button, FormControl } from "react-bootstrap"; 
import { useDispatch } from "react-redux";
import { addTodo } from "../features/todo/todoSlice";

function AddTodo(){
    const [title,setTitle]= useState('');
    const dispatch = useDispatch();
    function addToDos(event){
        console.log(title);
        event.preventDefault();
        dispatch(addTodo(title));
        setTitle('');

    }
    return(
        <form onSubmit={addToDos}>
            <input type="text" placeholder="Message to YOCGPT" value={title} onChange={ (e) =>{
                setTitle(e.target.value)
            }}
             />
             <Button type="submit" variant="primary">Add</Button>
        </form>
    )
}
export default AddTodo