import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Todo from './components/Todo'
import AddTodo from './components/Addtodo'
import Chatlog from './components/gpt/Chatlog'
import ChatContainer from './components/gpt/ChatContainer'
import { BrowserRouter } from 'react-router-dom'
// import User from './components/users/User'

function App() {
  //const [count, setCount] = useState(0)

  return (
    <>
    {/* <User></User> */}
      <BrowserRouter>
        <ChatContainer></ChatContainer>
      </BrowserRouter>

      {/* <h2>Learn about react js</h2> */}
      {/* <AddTodo></AddTodo> */}
      {/* <Todo></Todo> */}
    </>
  )
}

export default App
