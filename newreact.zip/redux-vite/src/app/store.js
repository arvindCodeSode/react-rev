import { configureStore } from "@reduxjs/toolkit";
import todoReducer from '../features/todo/todoSlice'
import chatSlideReducer from "../features/gpt/addChatSlice";
export const store = configureStore({
    reducer:{
        todos:todoReducer,
        gpts:chatSlideReducer
    }
})