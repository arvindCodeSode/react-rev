import './App.css'
import User from './components/users/User'

function App() {
  //const [count, setCount] = useState(0)

  return (
    <>
    <User></User>
    </>
  )
}

export default App
