import React from "react"
import { Button } from 'react-bootstrap';

const Home = (props) =>{
    console.log('Home', props)
    return (
        <>
            <div className="cart-wrapper">
                <div className="cart-img img item">
                    <img src="./app.jpg" alt="Apple Phone" width={100} />
                </div>
                <div className="cart-price item">
                    <span>Iphone</span><br /><span>2400</span>
                </div>
                <div className="cart-button item">
                    <Button variant="primary" onClick={()=>{ props.addToCardHandler({price:3000,title:'I-Phone 24'}) }}>Add Cart</Button><br />
                    <Button variant="Danger" onClick={()=>{ props.removeToCardHandler() }}>Remove Cart</Button>
                </div>
            </div>
        </>
    )
}
export default Home;