import React from "react"
import { Button } from "react-bootstrap"

const Header = (props)=>{
    console.log('header',props.data.length)
    console.log('header',props.data.length)
    return(
        <>
            <div className="cart-icon">
                <Button variant="info">Cart Item <span>{props.data.length}</span> </Button>
            </div>
        </>
    )
}
export default Header;