import logo from './logo.svg';

import './App.css';
import HeaderContainer from "./containers/HeaderContainer";
import HomeContainer from './containers/HomeContainer';
function App() {
  return (
    <div className="App">
      <h3>Products</h3>
      <HeaderContainer></HeaderContainer>
      <HomeContainer></HomeContainer>
    </div>
  );
}

export default App;
