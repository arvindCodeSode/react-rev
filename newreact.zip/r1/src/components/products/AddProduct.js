import React from "react";

const AddProdcut = ()=>{

    return <h1>Add Product</h1>
}   

export default AddProdcut