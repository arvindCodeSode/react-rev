import React from 'react'

const Navbar =  ()=>{

    return <h1>Navbar</h1>;
}
export default Navbar