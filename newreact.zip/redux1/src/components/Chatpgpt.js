import axios from "axios";
import { useEffect } from "react";

const Chatgpt = ()=>{

    useEffect(()=>{

    })
    
    return(
        <>
        <h1>Hello World</h1>
        <button onClick={getcall}>Get Call</button>
        </>
    )
}
export default Chatgpt;