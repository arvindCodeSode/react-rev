import React from "react";
import { Badge } from "react-bootstrap";
import { Button } from "react-bootstrap"
const Header = (props)=>{
    console.log(props)
    return(
        <>
            <div className="card-cart">
                <Button variant="info">Cart Items <Badge bg="primary">{props.data.length}</Badge> </Button>
            </div>
        </>
    )
}
export default Header;