import React from "react";
import { Button } from "react-bootstrap";
const Home = (props)=>{
    return(
        <>
            <h1>Product List</h1>
            <div className="card-wrapper">
                <div className="cart-image item">
                    <img src="app.jpg" alt="App" width={50} />
                </div>
                <div className="cart-price item">
                    <span>Price</span><br /><span>2000</span>
                </div>
                <div className="cart-button item">
                    <Button variant="primary" onClick={()=>{ props.addToCartHandler({price:1000,title:'IPhone 15'}) }}>Add To Cart</Button>
                    <Button variant="danger" onClick={()=>{ props.removeToCardHandler() }}>Remove To Cart</Button>
                </div>
            </div>
        </>
    )
}
export default Home;