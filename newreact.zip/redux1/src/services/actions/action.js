import { ADD_TO_CART, REMOVE_TO_CART } from "../contants"

export const addToCard = (data)=>{
    return{
        type:ADD_TO_CART,
        data:data
    }
}
export const removeToCard = (data)=>{
    return{
        type:REMOVE_TO_CART,
        data:data
    }
}