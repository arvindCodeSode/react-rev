import { cardItems } from "./reducer";
import { combineReducers } from "redux";

export default combineReducers({
    cardItems
})