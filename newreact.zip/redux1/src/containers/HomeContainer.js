import { connect } from "react-redux";
import { addToCard, removeToCard } from "../services/actions/action";
import Home from "../components/Home";

const mapStatesToProps = state=>({
    cardData:state
})
const mapDispatchToProps = dispatch =>({
    addToCartHandler:data=>dispatch(addToCard(data)),
    removeToCardHandler:data => dispatch(removeToCard(data))

})
export default connect(mapStatesToProps, mapDispatchToProps)(Home);