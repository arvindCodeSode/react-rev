import Header from "../components/Header";
import { connect } from "react-redux";

const mapStatesToProps = state=>({
    data:state.cardItems
})
const mapDispatchToProps = dispatch =>({
    // addToCartHan
})
export default connect(mapStatesToProps, mapDispatchToProps)(Header);