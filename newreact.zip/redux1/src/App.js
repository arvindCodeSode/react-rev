import logo from './logo.svg';
import './App.css';
import HomeContainer from './containers/HomeContainer';
import HeaderContainer from './containers/HeaderContainer';
// import Home from './components/Home';
import Chatgpt from './components/Chatpgpt';

function App() {
  return (
    <div className="App">
      <Chatgpt></Chatgpt>
      {/* <HeaderContainer></HeaderContainer> */}
        {/* <HomeContainer></HomeContainer> */}
    </div>
  );
}

export default App;
